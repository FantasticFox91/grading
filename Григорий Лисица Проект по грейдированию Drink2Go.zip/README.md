# Grading project for HTML Academy

**Затраченное время**
---
Примерно 22 часа
Ссылка на отчет(https://drive.google.com/file/d/1_TEFKJ3DEbOYICrbjtIXeGHr_Wqvq5GF/view?usp=sharing)
---
